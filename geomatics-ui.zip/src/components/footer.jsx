import React from "react";

export const Footer = (props) => {
  return (
    <div id="footer" >
        <div className="container text-center">
          <p>
           
          </p>
        </div>
      </div>
  );
};
