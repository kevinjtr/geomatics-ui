
import { Link } from "react-router-dom";
import { useState, useEffect } from "react";
import Landing from "../../templates/landing"
export function Geospatial(){
    
   return(
    <Landing/>
   )

    //return(
      
            //<Landing 
            //data={projectPageData.Apps}
            ///>
    //)
}